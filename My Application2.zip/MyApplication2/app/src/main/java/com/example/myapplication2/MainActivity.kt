package com.example.myapplication2

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val nome = findViewById<EditText>(R.id.nome)
        val email = findViewById<EditText>(R.id.email)
        val telefone = findViewById<EditText>(R.id.telefone)

        val nextButon = findViewById<Button>(R.id.nextButton)
        nextButon.setOnClickListener {

            val intent = Intent(this, Activity2::class.java)

            intent.putExtra("nome", nome.toString())
            intent.putExtra("email", email.toString())
            intent.putExtra("telefone", telefone.toString())

            startActivity(intent)

        }

        val instagramButton = findViewById<ImageView>(R.id.instagramIcon)
        instagramButton.setOnClickListener{
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/dermagebrasil/"))
            startActivity(intent)
        }

        val twitterButton = findViewById<ImageView>(R.id.twitterIcon)
        twitterButton.setOnClickListener{
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/DermageBrasil?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor"))
            startActivity(intent)
        }

    }
}
