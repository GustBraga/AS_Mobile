package com.example.myapplication2

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.RadioGroup
import androidx.activity.ComponentActivity

class Activity2 : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_2)

        val nome = intent.getStringExtra("nome")
        val email = intent.getStringExtra("email")
        val telefone = intent.getStringExtra("telefone")

        val nextButton = findViewById<Button>(R.id.nextButton)
        val votingRadioGroup = findViewById<RadioGroup>(R.id.radioGroup)

        nextButton.setOnClickListener {
            val selectedOption = when (votingRadioGroup.checkedRadioButtonId) {
                R.id.curta -> "Curta"
                R.id.pratica -> "Pratica"
                R.id.depende -> "Depende"
                R.id.longa -> "Longa"
                else -> ""
            }

            val intent = Intent (this, Activity3::class.java)

            intent.putExtra("nome", nome)
            intent.putExtra("email", email)
            intent.putExtra("telefone", telefone)
            intent.putExtra("opcao", selectedOption)

            startActivity(intent)
        }

        val instagramButton = findViewById<ImageView>(R.id.instagramIcon)
        instagramButton.setOnClickListener{
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/dermagebrasil/"))
            startActivity(intent)
        }

        val twitterButton = findViewById<ImageView>(R.id.twitterIcon)
        twitterButton.setOnClickListener{
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://twitter.com/DermageBrasil?ref_src=twsrc%5Egoogle%7Ctwcamp%5Eserp%7Ctwgr%5Eauthor"))
            startActivity(intent)
        }
    }
}